#include <iostream>
#include "Book.h";

using namespace std;
int main()
{
	Book p;
	p.bookMenu();
}

